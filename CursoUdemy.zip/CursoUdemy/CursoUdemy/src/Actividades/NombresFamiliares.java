package Actividades;

import javax.swing.*;

public class NombresFamiliares {
    public static void main(String[] args) {

        String nombre1 = JOptionPane.showInputDialog(null, "Ingrese el nombre y apellido del familiar");
        String nombre2 = JOptionPane.showInputDialog(null, "Ingrese el nombre de otro familiar");
        String nombre3 = JOptionPane.showInputDialog(null, "Ingrese el nombre de otro familiar");

        String max = (nombre1.split("")[0].length() > nombre2.split("")[0].length()) ? nombre1 : nombre2;
        max= (nombre3.split("")[0].length() < max.split(" ")[0].length()) ? max : nombre3;

        System.out.println("la persona con el nombre mas largo es " + max);

    }
}

