package Actividades;

public class MiNombre {
    public static void main(String[] args) {

        String nombreCompleto = "MAXIMO FIDELIBUS";


        System.out.println(nombreCompleto);
        System.out.println("nombreCompleto = " + nombreCompleto.toLowerCase()); //para escibir esta linea el atajo es soutv

        //int no cuenta con metodos porque es primitivo
        //Integer cuenta con metodos porque es referencial

        int numero = 11;
        System.out.println("numero = " + numero);
        boolean valor = true;

        String nombre2;

        nombre2 = "coloFide";

        if (numero>10){
            nombre2 = "Colito";
        }
        System.out.println("nombre2 = " + nombre2);









    }
}
