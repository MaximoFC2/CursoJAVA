public class Primitivos {
    public static void main(String[] args) {
        byte numeroByte = 7;
        System.out.println("numeroByte = " + numeroByte);
        System.out.println("tipo de yte corresppnde en byte a" + Byte.BYTES);
    }
}
