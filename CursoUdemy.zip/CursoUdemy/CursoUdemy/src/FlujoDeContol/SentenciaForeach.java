package FlujoDeContol;

public class SentenciaForeach {
    public static void main(String[] args) {

        int[] numeros = {1, 3, 5, 7, 9, 11, 13, 14};
        for (int num : numeros) {
            System.out.println(num);
        }

        String[] nombres = {"colo", "maxi", "octa", "mateo", "sabri", "ale"};

        for (String nombre : nombres) {
            System.out.println(nombre);
        }

    }
}
