package FlujoDeContol;

import java.util.Scanner;

public class SentenciaIfElse {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        float promedio = sc.nextFloat();
        if(promedio >= 6.5){
            System.out.println("el promedio es muy bueno");

        }else if (promedio >= 6.0){
            System.out.println("buen promedio");
        }else if(promedio >= 5.0){
            System.out.println("debes esforzarte mas");
        } else {
            System.out.println("desaprobado");
        }
    }
}
