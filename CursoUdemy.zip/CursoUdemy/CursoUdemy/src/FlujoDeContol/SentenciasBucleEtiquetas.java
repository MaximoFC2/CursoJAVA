package FlujoDeContol;

public class SentenciasBucleEtiquetas {
    public static void main(String[] args) {

        bucle:
        for (int i = 0; i < 5; i++) { //etiqueta del for para llamarlo desde otro bucle

            for (int j = 0; j < 5; j++) {
                if (i == 2) {
                    continue bucle;
                }
                System.out.println("i = " + i + ", j = " + j);
            }
        }



        bucle1: for (int i = 1; i <= 7; i++) { //etiqueta del for para llamarlo desde otro bucle
            System.out.println();
            int j = 1;

            while (j <= 8) {
                if (i == 6 || i == 7) {
                    System.out.println("Dia " + i + ": descanso de fin de semana!");
                    continue bucle1;
                }
                System.out.println("Dia " + i + ", trabajando a las  " + j + "hrs. ");
                j++;
            }
        }//ejecuta bucle1 para el dia 1 y ejecuta dentro un while para las 8hrs pero si el valor de la vuelta
        // de el bucle1 es 6 o 7 ejecuta el if y hace un continue para saltar directamente a la siguiente vuelta




































    }
}
