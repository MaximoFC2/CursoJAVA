package FlujoDeContol;

public class SentenciasBucleEtiquetasBuscar {
    public static void main(String[] args) {

        String frase = "tres trigo";
        String palabra = "trigo";
        int maxPalabra = palabra.length();
        int maxFrase = frase.length() - maxPalabra;
        int cantidad = 0;
        char letra = 'o';

        for (int i = 0; i <= maxFrase; i++) { //recorre caracter por caracter la frase
            System.out.println("i = " + i);
        }
        System.out.println(" ");

        for (int j = 0; j < maxPalabra; j++) { //recorre caracter por caracter la palabra

            System.out.println("j = " + j);
        }


       bucleP: for (int i = 0; i < maxFrase; i++) {
           int k = i;
            for (int j = 0; j < maxPalabra; j++) {

                if(frase.charAt(k++) != palabra.charAt(j)){
                    continue bucleP;
                }
            }

            cantidad++;
        }

        System.out.println("Encontrados: " + cantidad + " veces la palabra " + palabra + " en la frase");




















    }
}
