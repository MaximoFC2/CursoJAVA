package FlujoDeContol;

import javax.swing.*;

public class SentenciaForArreglo {
    public static void main(String[] args) {

        String[] nombres = {"colo","maxi","octa", "mateo","sabri","ale"};
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }








    }
}
