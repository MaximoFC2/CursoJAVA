package Actividades;

import java.sql.SQLOutput;
import java.util.Scanner;

public class EliminarElemento {
    public static void main(String[] args) {

        int[] a = new int[7];

        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < a.length; i++) {
            System.out.println("Digite un valor: ");
            a[i] = sc.nextInt();
        }

        System.out.println();

        System.out.println("el arreglo quedo asi: ");
        for (int i = 0; i < a.length; i++) {
            System.out.println(i + " => " + a[i]);
        }

        System.out.println("Elija la posicion del elemento que decida eliminar");

        int posicionEliminado = sc.nextInt();

        for (int i = posicionEliminado; i < a.length -1; i++) {//i comienza desde la posicion que queremos eliminar a partir de ahi
             a[i] = a[i+1];//en la posicion actual dejamos la siguiente porque desplaza hacia abajo todos los elementos
             //comienza a desplazar los elementos siguientes a la posicion actual (todos los elementos haci

        }
        System.out.println();
        System.out.println("Este es tu arreglo modificado");
        System.out.println();
        int[] b = new int[a.length -1];
        System.arraycopy(a,0,b,0,b.length);
        //a= desde que arreglo copiamos
        //0= desde que posicion copiamos
        //b= donde copiamos
        //b.length tamaño



        for (int i = 0; i < b.length; i++) {
            System.out.println(i + " => " + b[i]);
        }





    }
}
