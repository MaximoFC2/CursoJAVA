package Actividades;

import java.util.Scanner;

public class OrdenarElementosRequerimientos {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int[] a = new int[10];

        for (int i = 0; i < a.length; i++) {
            System.out.println("Digite un valor: ");
            a[i] = entrada.nextInt();

        }

        for (int i = 0; i < a.length/2 /* o -i */; i++) {

            System.out.println(a[a.length - 1 -i]);
            System.out.println(a[i] + " ");
        } //intercala los numeros colocando el primero con el ultimo, el segundo con el anteultimo y asi sus
        int aux = 0;
        for (int i = 0; i < a.length/2 /* o -i */; i++) {
            a[aux++] = a[i];
            a[aux++] = a[a.length - 1 -i];
        }
    }

}
