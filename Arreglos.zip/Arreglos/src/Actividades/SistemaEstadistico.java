package Actividades;

import java.util.Scanner;

public class SistemaEstadistico {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int[] a = new int[7];
        double sumPositivos = 0.0, sumNegativos = 0.0;
        int cantCeros = 0, cantPositivos = 0, cantNegativos = 0;

        for (int i = 0; i < a.length; i++) {
            System.out.println("Digite un valor: ");
            a[i] = entrada.nextInt();
            if (a[i] > 0) {
                sumPositivos += a[i];
                cantPositivos++;
            }else if(a[i] < 0) {
                sumNegativos += a[i];
                cantNegativos++;
            }else if(a[i] == 0) {
                cantCeros ++;
            }
        }

        double promedioPositivos = sumPositivos / cantPositivos;
        double promedioNegativos = sumNegativos / cantNegativos;

        System.out.println("El promedio de positivos es: " + promedioPositivos);
        System.out.println("El promedio de negativos es: " + promedioNegativos);
        System.out.println("La cantidad de ceros es: " + cantCeros);


    }
}
