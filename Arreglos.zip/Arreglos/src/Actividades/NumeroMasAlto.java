package Actividades;

import java.util.Scanner;

public class NumeroMasAlto {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] a = new int[7];

        for (int i = 0; i < a.length; i++) {
            System.out.println("Digite un numero: ");
            a[i] = sc.nextInt();
        }

        int max = 0;
        for (int i = 1; i < a.length; i++) {
            max = (a[max] > a[i]) ? max : i;

        }
        System.out.println("El numero Mayor es = " + a[max]);
    }
}
