package Actividades;

import java.util.Scanner;

public class AgregarElementoPosicionIndicada {
    public static void main(String[] args) {

        int[] a = new int[10];
        Scanner entrada = new Scanner(System.in);

        for (int i = 0; i < a.length-1; i++) {
            System.out.println("Digite un valor: ");
            a[i] = entrada.nextInt();
        }

        System.out.println("Ingrese un valor que desea insertar");
        int valorInsertado = entrada.nextInt();
        System.out.println("Ingrese la posicion en la cual edsea insertar este valor");
        int posicionInsertado = entrada.nextInt();

        for (int i = a.length -2; i >= posicionInsertado; i--) {
            a[i+1] = a[i];
        }
        a[posicionInsertado] = valorInsertado;

        System.out.println("El arreglo");
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }





    }
}
