package Actividades;

import java.util.Scanner;

public class AgrandarArreglo {
    public static void main(String[] args) {

        int[] a = new int[10];
        Scanner entrada = new Scanner(System.in);
        int valorInsertado, posicionInsertado, ultimo;

        for (int i = 0; i < a.length; i++) {
            System.out.println("Digite un valor: ");
            a[i] = entrada.nextInt();
        }

        System.out.println("Ingrese un valor que desea insertar");
         valorInsertado = entrada.nextInt();
        System.out.println("Ingrese la posicion en la cual edsea insertar este valor");
         posicionInsertado = entrada.nextInt();

         ultimo = a[a.length - 1];

        for (int i = a.length -2; i >= posicionInsertado; i--) {
            a[i+1] = a[i];
        }




        int[] b = new int[a.length +1];

        System.arraycopy(a,0,b,0,a.length);
        b[posicionInsertado] = valorInsertado; //insertamos en la posicion seleccionada

        b[b.length-1] = ultimo;//pasamos el ultimo elemento respaldado desde antes

        a = b;

        a[posicionInsertado] = valorInsertado;
        a[a.length-1] = ultimo;

        System.out.println("El arreglo");
        for (int i = 0; i < b.length; i++) {
            System.out.println(b[i]);
        }








    }
}
