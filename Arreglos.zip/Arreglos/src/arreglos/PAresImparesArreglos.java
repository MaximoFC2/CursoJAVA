package arreglos;

import java.util.Scanner;

public class PAresImparesArreglos {
    public static void main(String[] args) {

        int[] a, pares, impares;
        int cantPares = 0;
        int cantImpares = 0;

        a = new int[10];
        Scanner sc = new Scanner(System.in);
        System.out.println("ingresa 10 numeros");

        for (int i = 0; i < a.length; i++) {
            a[i] = sc.nextInt();
        }

        for (int i = 0; i < a.length; i++) {
            if(a[i] % 2 == 0) {
                cantPares++;
            }else{
                cantImpares++;
            }
        }

        pares = new int[cantPares];
        impares = new int[cantImpares];

        int p = 0;
        int im = 0;

        for (int i = 0; i < a.length; i++) {
            if(a[i] % 2 == 0) {
                pares[p++] = a[i];
            }else {
                impares[im++] = a[i];
            }
        }

        System.out.println("Pares: " + cantPares);
        for (int i = 0; i < p; i++) {
            System.out.print(pares[i] + " ");
        }

        System.out.println("\r\nImpares: " + cantImpares);
        for (int i = 0; i < im; i++) {
            System.out.print(impares[i] + " ");
        }


    }
}
