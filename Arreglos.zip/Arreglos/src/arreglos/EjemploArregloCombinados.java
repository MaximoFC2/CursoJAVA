package arreglos;

public class EjemploArregloCombinados {
    public static void main(String[] args) {
        int[] a, b, c;
        a = new int[10];
        b = new int[10];
        c = new int[20];

        for (int i = 0; i < a.length; i++) {
            a[i] = i+1;
        }

        for (int i = 0; i < b.length; i++) {
            b[i] = (i+1) * 5;
        }

        int aux = 0;

        for (int i = 0; i < 10; i++) { //cargo el arreglo c con los valoresd de los arreglos a y b
            c[aux++]= a[i];  //carga y muestra los valores intercalados primero un valor de a y luego uno de b asi sus
            c[aux++]= b[i];
        }

        for (int i = 0; i < c.length; i++) {
            System.out.println(i + ": " + c[i]);
        }

    }
}
