package arreglos;

import java.util.Arrays;

public class EjemploArrgelosForInversoMutable {
    public static void main(String[] args) {


        String[] productos = new String[7];
        int total = productos.length;


        productos[0] = "Kington Pendrive 64gb";
        productos[1] = "Samsung Galaxy";
        productos[2] = "Disco Duro ssd Samsung externo";
        productos[3] = "Monitor asus 144hz 24'";
        productos[4] = "Teclado kumara 552";
        productos[5] = "Mouse logitech g305";
        productos[6] = "Web cam genius 1080p";

        Arrays.sort(productos);
        //Collections.reverse(Arrays.asList(productos)); da vuelta
        System.out.println("====Usando For====");
        for (int i = 0; i < total; i++) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }

        for (int i = 0; i < total/2; i++) { //se puede crear nueva variable local2 y hacer un decremento al final
            String actual = productos[i];
            String inverso = productos[total-i-1];
            productos[i] = inverso;
            productos[total-i-1] = actual;
            //total2 --
        }

        System.out.println("====Usando For Mutado====");

        for (int i = 0; i < total; i++) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }






    }
}
