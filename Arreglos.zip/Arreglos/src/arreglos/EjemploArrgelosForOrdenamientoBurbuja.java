package arreglos;

public class EjemploArrgelosForOrdenamientoBurbuja {

    public static void sortBurbuja(Object[] arreglo) {
        int total = arreglo.length;
        int contador = 0;
        for (int i = 0; i < total - 1; i++) {
            for (int j = 0; j < total - 1 - i; j++) {
                if (((Comparable) arreglo[j + 1]).compareTo(arreglo[j]) < 0) { //cambiar < por > si quisiera cambiar orden
                    Object auxiliar = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = auxiliar;
                }
                contador++;
            }
        }
        System.out.println("contador = " + contador);
    }

    public static void main(String[] args) {


        String[] productos = new String[7];
        productos[0] = "Kington Pendrive 64gb";
        productos[1] = "Samsung Galaxy";
        productos[2] = "Disco Duro ssd Samsung externo";
        productos[3] = "Monitor asus 144hz 24'";
        productos[4] = "Teclado kumara 552";
        productos[5] = "Mouse logitech g305";
        productos[6] = "Web cam genius 1080p";

        int total = productos.length;


        sortBurbuja(productos);
        System.out.println("====Usando For====");
        for (int i = 0; i < total; i++) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }

        Integer[] numeros = new Integer[4];

        numeros[0] = 1;
        numeros[1] = 5;
        numeros[2] = -8;
        numeros[3] = 102;

        sortBurbuja(numeros);


        for (int i = 0; i < numeros.length; i++) {
            System.out.println("numeros = " + i + " : " + numeros[i]);
        }


    }
}
