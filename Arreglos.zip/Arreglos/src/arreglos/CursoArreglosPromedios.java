package arreglos;

import java.util.Scanner;

public class CursoArreglosPromedios {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        double[] cMatematicas, cHistoria, cLenguas;
        cMatematicas = new double[7]; // 7 alumnos
        cHistoria = new double[7];
        cLenguas = new double[7];

        double sumNotasMatematicas = 0;
        double sumNotasHistoria = 0;
        double sumNotasLenguas = 0;



        System.out.println("Ingrese 7 notas de estudiantes para matematica");

        for (int i = 0; i < cMatematicas.length; i++) {
            cMatematicas[i] = sc.nextDouble();
        }

        System.out.println("Ingrese 7 notas de estudiantes para Historia");

        for (int i = 0; i < cHistoria.length; i++) {
            cHistoria[i] = sc.nextDouble();
        }

        System.out.println("Ingrese 7 notas de estudiantes para Lengua");

        for (int i = 0; i < cLenguas.length; i++) {
            cLenguas[i] = sc.nextDouble();
        }

        for (int i = 0; i < 7; i++) {
            sumNotasMatematicas += cMatematicas[i];
            sumNotasHistoria += cHistoria[i];
            sumNotasLenguas += cLenguas[i];
        }

        double promedioMatematicas = sumNotasMatematicas/cMatematicas.length;
        double promedioHistoria = sumNotasHistoria/cHistoria.length;
        double promedioLenguas = sumNotasLenguas/cLenguas.length;
        double promedioTotal = (promedioLenguas + promedioMatematicas + promedioHistoria) / 3;

        System.out.println("Promedio clase matematicas: " + promedioMatematicas);
        System.out.println("Promedio clase Historia: " + promedioHistoria);
        System.out.println("Promedio Clase Lenguas: " + promedioLenguas);

        System.out.println("Promedio total del curso: " + promedioTotal);

        System.out.println( "Ingrese identificador del alumno (0-6)");
        int id = sc.nextInt();
        double promedioAlumno = (cHistoria[id] + cMatematicas[id] + cLenguas[id])/3;
        System.out.println("Promedio Alumno Nro = " + id + " : " + promedioAlumno);






    }
}
