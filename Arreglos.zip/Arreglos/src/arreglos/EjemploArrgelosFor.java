package arreglos;

import java.util.Arrays;

public class EjemploArrgelosFor {
    public static void main(String[] args) {

        String[] productos = new String[7];
        int total = productos.length;


        productos[0] = "Kington Pendrive 64gb";
        productos[1] = "Samsung Galaxy";
        productos[2] = "Disco Duro ssd Samsung externo";
        productos[3] = "Monitor asus 144hz 24'";
        productos[4] = "Teclado kumara 552";
        productos[5] = "Mouse logitech g305";
        productos[6] = "Web cam genius 1080p";

        Arrays.sort(productos);
        System.out.println("====Usando For====");
        for (int i = 0; i < total; i++) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }
        System.out.println("====Usando ForEach====");
        for(String producto: productos) {
            System.out.println("producto = " + producto);
        }
        System.out.println("====Usando While====");
        int i = 0;
        while(i < total){
            System.out.println("para indice " + i + ": " + productos[i]);
            i++;
        }
        System.out.println("====Usando DoWhile====");
        int j = 0;
        do {
            System.out.println("para indice " + j + ": " + productos[j]);
            j++;
        }while(j < total);





        int[] numeros = new int[10];
        int total2 = numeros.length;

        for(int k = 0; k < total2; k++){
          numeros[k] = k*3;
        }
        for(int k = 0; k < total2; k++){
            System.out.println("numeros = " + numeros[k]);
        }




    }
}
