package arreglos;

import java.util.Arrays;

public class EjemploArrgelosForInverso {
    public static void main(String[] args) {

        String[] productos = new String[7];
        int total = productos.length;


        productos[0] = "Kington Pendrive 64gb";
        productos[1] = "Samsung Galaxy";
        productos[2] = "Disco Duro ssd Samsung externo";
        productos[3] = "Monitor asus 144hz 24'";
        productos[4] = "Teclado kumara 552";
        productos[5] = "Mouse logitech g305";
        productos[6] = "Web cam genius 1080p";

        Arrays.sort(productos);
        System.out.println("====Usando For====");
        for (int i = 0; i < total; i++) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }
        System.out.println("====Usando For Inverso====");
        for (int i = 0; i < total; i++) { //recorrer de forma invertida un for -i-1 del total
            System.out.println("para indice " + (total-1-i) + ": " + productos[total-i-1]);
        }
        System.out.println("====Usando For Inverso 2====");
        for(int i = total -1; i >= 0; i--) {
            System.out.println("para indice " + i + ": " + productos[i]);
        }





    }
}
