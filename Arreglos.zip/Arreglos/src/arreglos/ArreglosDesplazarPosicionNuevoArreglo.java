package arreglos;

import java.util.Scanner;

public class ArreglosDesplazarPosicionNuevoArreglo {
    public static void main(String[] args) {

        int[] a = new int[7];
        Scanner sc = new Scanner(System.in);
        int numero, posicion, ultimo;


        for (int i = 0; i < a.length; i++) {
            System.out.print("Ingresa un numero: ");
            a[i] = sc.nextInt();
        }

        System.out.println();
        System.out.println("Ingrese un numero a insertar: ");

        numero = sc.nextInt();
        ultimo = a[a.length - 1];

        posicion = 0;

        while(posicion < 6 && numero > a[posicion]) { // posicion va a incrementar mientras sea menor que 6 y el numero ingresado
            posicion++;// sea mayor al numero que hay en la posicion de esa vuelta de while por ejem si ingresamos 5 y valida
        } // que va en la vuelta 3 y el valor de esa posicion es 4 entonces aumenta en 1 el valor de posicion para seguir

        for(int i = a.length-2; i >= posicion; i--) {//luego aca si el valor de la siguiente posicion llegara a ser 6
            a[i+1] = a[i];//valida que numero no es mayor que el valor de la posicion...
        }                 //entonces desplaza el 6 y queda en su lugar el 5...

        int[] b = new int[a.length +1];
        System.arraycopy(a, 0, b, 0, a.length);
        if(numero> ultimo){
            b[b.length -1] = numero;
        }else{
            b[b.length -1] = ultimo;
            b[posicion] = numero;
        }



        System.out.println("El Arreglo ordenado nuevamente queda: ");
        for(int i = 0; i < b.length; i++) {
            System.out.println(i + " => " + b[i] );
        }


    }
}
