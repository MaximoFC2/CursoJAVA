package arreglos;

import java.util.Scanner;

public class EjemploArreglosBuscarStrings {
    public static void main(String[] args) {

        String[] a = new String[4];

        Scanner entrada = new Scanner(System.in);

        for (int i = 0; i < a.length; i++) {
            System.out.print("Digite un texto letra o lo que quiera: ");
            a[i] = entrada.next();
        }


        System.out.println("\r\nIngrese un texto a buscar");
        String nombre = entrada.next();
        int i = 0;
        for (; i < a.length && !a[i].equalsIgnoreCase(nombre); i++ ) {
            i++;
        }
        if (i == a.length) {
            System.out.println("Texto no encontrado");
        }else if (a[i].toLowerCase().compareTo(nombre.toLowerCase()) == 0) {

            System.out.println("Texto encontrado en la posicion: " + (i + 1));
        }
    }
}
