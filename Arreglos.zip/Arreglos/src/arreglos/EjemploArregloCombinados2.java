package arreglos;

public class EjemploArregloCombinados2 {
    public static void main(String[] args) {
        int[] a, b, c;
        a = new int[10]; //si quisiera mostrar 3 de c/u deberia de colocar numeros multiplod de 3
        b = new int[10]; //por ejemplo a con 9 lugares b con 9  y c con 18
        c = new int[20];//y en los for en lugar de incrementar de 2 en 2, colocar 3

        for (int i = 0; i < a.length; i++) {
            a[i] = i+1;
        }

        for (int i = 0; i < b.length; i++) {
            b[i] = (i+1) * 5;
        }

        int aux = 0;

        for (int i = 0; i < 10; i+=2) { //cargo el arreglo c con los valoresd de los arreglos a y b
           for (int j = 0; j < 2; j++) {  //carga y muestra los valores intercalados primero 2 valores de a y luego 2 de b asi sus
               c[aux++]= a[i+j];
           }
            for (int j = 0; j < 2; j++){
                c[aux++]= b[i+j];
            }


        }

        for (int i = 0; i < c.length; i++) {
            System.out.println(i + ": " + c[i]);
        }

    }
}
