package arreglos;

import java.util.Scanner;

public class EjemploArreglosBuscarEnteros {
    public static void main(String[] args) {

        int[] a = new int[10];

        Scanner entrada = new Scanner(System.in);

        for (int i = 0; i < a.length; i++) {
            System.out.print("Digite un numero: ");
            a[i] = entrada.nextInt();
        }


        System.out.println("\r\nIngrese un numnero a buscar");
        int num = entrada.nextInt();
        int i = 0;
        while (i < a.length && a[i] != num) {
            i++;
        }
        if (i == a.length) {
            System.out.println("Numero no encontrado");
        }else if (a[i] == num) {

            System.out.println("Numero encontrado en la posicion: " + (i + 1));
        }
    }
}
